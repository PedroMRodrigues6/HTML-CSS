function trocaCor(cor){
    let circulo = document.querySelector(".circulo")
    circulo.style.background = cor
}

function trocaIphone(imagem){
    let iphone = document.querySelector(".iphone")
    iphone.src = imagem
}